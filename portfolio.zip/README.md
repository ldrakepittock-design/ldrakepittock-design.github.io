# Lauren Pittock — Portfolio

A clean, minimal portfolio website with password-protected case studies.
Built as static HTML/CSS/JS — free to host on GitHub Pages.

---

## 🔐 Changing Your Password

Open `gate.html` and find this line near the top of the `<script>` block:

```js
const PASSWORD = "portfolio2024";
```

Change `"portfolio2024"` to any password you'd like. Save the file and re-upload.

---

## 🚀 How to Publish on GitHub Pages (Free Hosting)

Follow these steps — no coding required.

### Step 1: Create a GitHub account
Go to [github.com](https://github.com) and sign up for a free account if you don't have one.

### Step 2: Create a new repository
1. Click the **+** icon (top right) → **New repository**
2. Name it exactly: `your-username.github.io`
   - Replace `your-username` with your actual GitHub username
   - Example: if your username is `laurenpittock`, name it `laurenpittock.github.io`
3. Set it to **Public**
4. Click **Create repository**

### Step 3: Upload your files
1. On the repository page, click **Add file → Upload files**
2. Drag and drop ALL the files from this folder:
   - `index.html`
   - `style.css`
   - `gate.html`
   - `case-keybank-inbranch.html`
   - `case-united-smb.html`
   - `case-intuit-onboarding.html`
   - `case-diabetes-app.html`
   - `case-marketing-offers.html`
3. Scroll down, click **Commit changes**

### Step 4: Enable GitHub Pages
1. Go to your repository's **Settings** tab
2. Click **Pages** in the left sidebar
3. Under **Source**, select **Deploy from a branch**
4. Choose **main** branch, **/ (root)** folder
5. Click **Save**

### Step 5: Your site is live!
Wait 1–2 minutes, then visit:
`https://your-username.github.io`

---

## 📁 File Structure

```
portfolio/
├── index.html                    ← Homepage
├── style.css                     ← All styles
├── gate.html                     ← Password gate (shared by all case studies)
├── case-keybank-inbranch.html    ← Case study 1
├── case-united-smb.html          ← Case study 2
├── case-intuit-onboarding.html   ← Case study 3
├── case-diabetes-app.html        ← Case study 4
├── case-marketing-offers.html    ← Case study 5
└── README.md                     ← This file
```

---

## 🖼️ Adding Images to Case Studies

Each case study has placeholder blocks labeled "Add your [artifact] here."
To replace them with real images:

1. Add your image file to the portfolio folder (e.g., `keybank-blueprint.jpg`)
2. Find the `<div class="img-placeholder">` block you want to replace
3. Replace the entire div with:
```html
<img src="keybank-blueprint.jpg" alt="Service blueprint" style="width:100%; border-radius:4px; margin: 2rem 0;" />
```

---

## ✏️ Updating Content

All content is in plain HTML — just open any `.html` file in a text editor and edit.
Key spots to personalize:
- **Hero tagline**: `index.html` → `.hero-title`
- **Case study outcomes**: Each `case-*.html` → `.outcome-grid`
- **Contact email**: All files → search `ldrakepittock@gmail.com`
- **Password**: `gate.html` → `const PASSWORD = "portfolio2024";`
